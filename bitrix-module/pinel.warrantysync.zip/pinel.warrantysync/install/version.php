<?php

$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "2026-08-20 00:00:00",
);
